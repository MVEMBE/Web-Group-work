
<?php
/*session_start();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

#$institution_id = $_SESSION['institution_id'];

$query = "SELECT * FROM courses WHERE institution_id = ?";
#$stmt = $conn->prepare($query);
#$stmt->bind_param("i", $institution_id);
#$stmt->execute();
#$courses_result = $stmt->get_result();
#$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h3>Institute Dashboard</h3>
        </header>
        <div>
            <button class="cann"><a href="institute_dashboard.php">Cancel</a></button>
        </div>
    
        <form action="add_course.php" method="POST">
        <h3>Add Course</h3>
            <input type="text" name="name" placeholder="Course Name" required>
            <input type="text" name="qualifications_required" placeholder="Qualifications" required><br><br>
            <button type="submit" name="add_course">Add Course</button>
        </form>
    </div>
</body>
</html>
