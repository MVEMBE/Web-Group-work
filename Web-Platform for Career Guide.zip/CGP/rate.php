<?php
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "cgd");

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed.']));
}

$item_id = intval($_POST['item_id']);
$rating = intval($_POST['rating']);
$user_id = 1;

if ($rating < 1 || $rating > 5) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid rating.']);
    exit;
}

$sql = "INSERT INTO ratings (item_id, user_id, rating) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE rating = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $item_id, $user_id, $rating, $rating);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Rating submitted successfully!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to submit rating.']);
}

$stmt->close();
$conn->close();
?>
