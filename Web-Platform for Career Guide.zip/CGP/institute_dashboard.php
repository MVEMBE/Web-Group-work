<?php
session_start();
if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$query = "SELECT * FROM faculties";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="man">
        <header>
            <h2>Institute Dashboard</h2>
        </header>

        <div>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <style>
                .star {
                    font-size: 24px;
                    color: gray;
                    cursor: pointer;
                }

                .star.selected {
                    color: gold;
                }
            </style>
            </head>

            <body>
                <h3>Rate Us</h3>
                <div id="stars" data-item-id="1">
                    <span class="star" data-value="1">&#9733;</span>
                    <span class="star" data-value="2">&#9733;</span>
                    <span class="star" data-value="3">&#9733;</span>
                    <span class="star" data-value="4">&#9733;</span>
                    <span class="star" data-value="5">&#9733;</span>
                </div>
                <p id="feedback"></p>

                <script>
                    $(document).ready(function() {
                        $(".star").on("mouseover", function() {
                            let value = $(this).data("value");
                            $(".star").each(function(index) {
                                $(this).toggleClass("selected", index < value);
                            });
                        });

                        $(".star").on("mouseout", function() {
                            $(".star").removeClass("selected");
                        });

                        $(".star").on("click", function() {
                            let rating = $(this).data("value");
                            let itemId = $("#stars").data("item-id");

                            $.post("rate.php", {
                                item_id: itemId,
                                rating: rating
                            }, function(response) {
                                $("#feedback").text(response.message);
                            }, "json");
                        });
                    });
                </script>
            </body>
        </div>

        <div>
            <div class="mybut">
                <button><a href="institute_view_applications.php">View Applications</a></button>
            </div><br>

            <div class="mybut">
                <button><a href="publish_admissions.php">Publish Admissions</a></button>
            </div>
        </div>

        <div>
            <button> <a href="ad_faculty.php"> Add Faculty</a></button>
        </div>

        <h3>Existing Faculties</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Actions</th>
            </tr>
            <?php while ($faculty = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $faculty['name']; ?></td>
                    <td>
                        <button class="canadd"> <a href="edit_faculty.php?id=<?= $faculty['faculty_id']; ?>">Edit</a></button>
                        <button class="canaddy"> <a href="delete_faculty.php?id=<?= $faculty['faculty_id']; ?>">Delete</a></button>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>


    <?php
    $query = "SELECT * FROM courses";
    $result = $conn->query($query);
    ?>

    <div class="man">
        <header>
            <h2>Institute Dashboard</h2>
        </header>

        <div>
            <button><a href="ad_course.php">Add Course</a></button>
        </div>

        <h3>Existing Courses</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Actions</th>
            </tr>
            <?php while ($course = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $course['name']; ?></td>
                    <td>
                        <button class="canadd"> <a href="edit_course.php?id=<?= $course['course_id']; ?>">Edit</a></button>
                        <button class="canaddy"> <a href="delete_course.php?id=<?= $course['course_id']; ?>">Delete</a></button>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>

</html>