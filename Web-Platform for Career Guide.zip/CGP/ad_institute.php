
<?php

session_start();
/*if ($_SESSION['role'] !== 'admin') {
    header("Location: Admin_Login.php"); 
    exit;
}*/

include('db_connection.php');

$query = "SELECT * FROM institutions";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="man">
        <header>
            <h2>Admin Dashboard</h2>
        </header>

        <div>
            <button class="cann"><a href="admin_dashboard.php">Cancel</a></button>
        </div>

        <form action="add_institution.php" method="POST">
        <h3>Add New Institution</h3>
            <input type="text" name="name" placeholder="Institution Name" required>
            <input type="text" name="type" placeholder="Institution Type">
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="contact" placeholder="Contact Number" required><br><br>
            <button type="submit" name="add_institution">Add Institution</button>
        </form>
    </div>
</body>
</html>
