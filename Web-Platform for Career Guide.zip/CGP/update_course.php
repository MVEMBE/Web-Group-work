<?php
/*
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $course_id = $_POST['course_id'];
    $name = $_POST['name'];

    $query = "UPDATE courses SET name = ? WHERE course_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $course_id);

    if ($stmt->execute()) {
        echo "Course information updated successfully!";
    } else {
        echo "Error updating Course!: " . $stmt->error;
    }

    $stmt->close();
    
    header("Location: institute_dashboard.php?");
    exit;
}
*/


session_start();
include('db_connection.php');

if (isset($_POST['course_id']) && isset($_POST['name'])) {
    $course_id = $_POST['course_id'];
    $name = $_POST['name'];

    $query = "UPDATE students SET name = ? WHERE course_id = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("ss", $name, $course_id);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Course information updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating faculty: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error'] = "Error preparing the statement: " . $conn->error;
    }

    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        header("Location: institute_dashboard.php?id=" . urlencode($id));
    } else {
        header("Location: institute_dashboard.php");
    }
    exit;
} else {
    $_SESSION['error'] = "Invalid input!";
    header("Location: institute_dashboard.php");
    exit;
}
?>