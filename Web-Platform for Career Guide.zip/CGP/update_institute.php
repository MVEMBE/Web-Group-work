<?php

/*include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $institution_id = $_POST['institution_id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $query = "UPDATE students SET name = ?, type = ?, address = ?, contact = ? WHERE institution_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $type, $address, $contact, $institution_id);

    if ($stmt->execute()) {
        echo "Institute information updated successfully!";
    } else {
        echo "Error updating Institute: " . $stmt->error;
    }

    $stmt->close();
    
    header("Location: admin_dashboard.php?id=" . $id);
    exit;
}
*/

session_start();
include('db_connection.php');

if (isset($_POST['institution_id']) && isset($_POST['name'])) {
    $faculty_id = $_POST['institution_id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $query = "UPDATE students SET name = ?, type = ?, address = ?, contact = ? WHERE institution_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $name, $type, $address, $contact, $institution_id);

    if ($stmt) {

        if ($stmt->execute()) {
            $_SESSION['message'] = "Institution information updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating Institution: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error'] = "Error preparing the statement: " . $conn->error;
    }

    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        header("Location: institute_dashboard.php?id=" . urlencode($id));
    } else {
        header("Location: institute_dashboard.php");
    }
    exit;
} else {
    $_SESSION['error'] = "Invalid input!";
    header("Location: admin_dashboard.php");
    exit;
}
?>