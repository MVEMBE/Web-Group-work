<?php

session_start();
/*if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

if (isset($_GET['application_id']) && isset($_GET['status'])) {
    $application_id = $_GET['application_id'];
    $status = $_GET['status'];

    $query = "UPDATE applications SET application_status = ? WHERE application_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $application_id);

    if ($stmt->execute()) {
        echo "Application status updated successfully.";
        header("Location: institute_view_applications.php");
    } else {
        echo "Something wrong! Please try again.";
        exit;
    }
}

