<?php
session_start();
/*if ($_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

if (isset($_GET['course_id'])) {
    $course_id = (int)$_GET['course_id'];
    #$student_id = $_SESSION['user_id'];

    $query = "SELECT COUNT(*) FROM applications WHERE student_id = ? AND course_id IN (SELECT course_id FROM courses WHERE faculty_id IN (SELECT faculty_id FROM faculties WHERE institution_id = (SELECT institution_id FROM courses WHERE course_id = ?)))";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $student_id, $course_id);
    $stmt->execute();
    $stmt->bind_result($num_apps);
    $stmt->fetch();

    if ($num_apps >= 2) {
        echo "You can only apply for a maximum of 2 courses at this institution.";
    } else {

        $query = "INSERT INTO applications (student_id, course_id) VALUES (?, ?)";
        #$stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $student_id, $course_id);
        if ($stmt->execute()) {
            echo "Application successful!";
        } else {
            echo "Something went wrong, please try again.";
            exit;
        }
    }
}
