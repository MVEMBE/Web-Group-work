<?php
session_start();
/*if ($_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit;
}
*/

include('db_connection.php');

$query = "SELECT * FROM admissions";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admissions</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="man">
        <header>
            <h2>Student Dashboard</h2>
        </header>

        <div>
            <button class="cann"><a href="student_dashboard.php">Back</a></button>
        </div>

        <h3>Published Admissions</h3>
        <table>
            <tr>
                <th>Student Name</th>
                <th>Course</th>
            </tr>
            <?php while ($admission = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $student['name']; ?></td>
                    <td><?= $course['name']; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>