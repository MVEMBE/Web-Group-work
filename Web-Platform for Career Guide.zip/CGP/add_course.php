
<?php
session_start();
/*if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

if (isset($_POST['add_course'])) {
    $name = $_POST['name'];
    $qualifications_required = $_POST['qualifications_required'];

    $query = "INSERT INTO courses (name, qualifications_required) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $name, $qualifications_required);

    if ($stmt->execute()) {
        header("Location: institute_dashboard.php");
    } else {
        echo "Something went wrong, please try again.";
        exit;
    }
}