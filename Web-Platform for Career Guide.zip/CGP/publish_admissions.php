<?php

session_start();
/*if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

if (isset($_POST['publish'])) {
    $course_id = $_POST['course_id'];
    $open_status = $_POST['open_status'];

    $query = "UPDATE admissions SET open_status = ? WHERE course_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $open_status, $course_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Admissions status updated successfully!";
    } else {
        $_SESSION['error'] = "Error updating faculty: " . $stmt->error;
    }

    if (isset($_POST['publish'])) {
        header("Location: institute_dashboard.php?");
        exit;
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="man">
        <header>
            <h1>Publish-Admissions</h1>
        </header>

        <div>
            <button class="cann"><a href="institute_dashboard.php">Back</a></button>
        </div>

        <?php
        $query = "SELECT * FROM courses";
        $result = $conn->query($query);
        ?>

        <form action="publish_admissions.php" method="POST">
            <select name="course_id" class="sho">
                <?php while ($course = $result->fetch_assoc()) { ?>
                    <option><?= $course['name']; ?></option>
                <?php } ?>
            </select>
            <select name="open_status" class="sho">
                <option value="open">Open</option>
                <option value="closed">Closed</option>
            </select>
            <button type="submit" name="publish">Publish</button>
        </form>

    </div>
</body>

</html>